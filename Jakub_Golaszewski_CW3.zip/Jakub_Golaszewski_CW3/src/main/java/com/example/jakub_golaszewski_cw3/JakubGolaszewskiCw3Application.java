package com.example.jakub_golaszewski_cw3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JakubGolaszewskiCw3Application {
    public static void main(String[] args) {
        SpringApplication.run(com.example.jakub_golaszewski_cw3.JakubGolaszewskiCw3Application.class, args);
    }
}